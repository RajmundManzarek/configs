
//
//
//            ####  #  ####    ####
//           #      #      #  #
//          #       #       ##         (C) 2023 SIX Financial Information
//         #        #       ##             All rights reserved
//        #         #      #  #
//    ####          #  ####    ####
//
//
//
#define BOOST_TEST_MODULE createlog_utils_lib_tests


#include "boost/test/included/unit_test.hpp"
#include "utils.h"


using namespace cl;
using namespace std;


BOOST_AUTO_TEST_CASE( toLower_test_A )
{
   char expected = 'a';
   char result = toLower('A');

   BOOST_TEST(result == expected);
}


BOOST_AUTO_TEST_CASE( toLower_test_a )
{
   char expected = 'a';
   char result = toLower('a');

   BOOST_TEST(result == expected);
}


BOOST_AUTO_TEST_CASE( toLower_test_other )
{
   char expected = '$';
   char result = toLower('$');

   BOOST_TEST(result == expected);
}


BOOST_AUTO_TEST_CASE( toValue_test_ok )
{
   string input{ "12345" };
   uint64_t result = toValue(input);
   decltype(result) expected = 12345;

   BOOST_TEST(result == expected);
}


BOOST_AUTO_TEST_CASE( toValue_test_throw )
{
   string input{ "9999999999999999999999999999999999999999999999999" };

   BOOST_REQUIRE_THROW(toValue(input), ConversionError);
}


BOOST_AUTO_TEST_CASE( ston_uint8_t )
{
    string input("126");
    auto output = ston<uint8_t>(input);
    decltype(output) expected = 126;

    BOOST_TEST(output == expected);
}


BOOST_AUTO_TEST_CASE( ston_uint8_t_throw )
{
    string input("300");

    BOOST_REQUIRE_THROW(ston<uint8_t>(input), ConversionError);
}


BOOST_AUTO_TEST_CASE( ston_uint8_t_bad )
{
    string input("very bad");

    BOOST_REQUIRE_THROW(ston<uint8_t>(input), ConversionError);
}


BOOST_AUTO_TEST_CASE( ston_uint16_t )
{
    string input("32767");
    auto output = ston<uint16_t>(input);
    decltype(output) expected = 32767;

    BOOST_TEST(output == expected);
}


BOOST_AUTO_TEST_CASE( ston_uint16_t_throw )
{
    string input("70000");

    BOOST_REQUIRE_THROW(ston<uint16_t>(input), ConversionError);
}


BOOST_AUTO_TEST_CASE( ston_uint16_t_bad )
{
    string input("very bad");

    BOOST_REQUIRE_THROW(ston<uint16_t>(input), ConversionError);
}


BOOST_AUTO_TEST_CASE( ston_uint32_t )
{
    string input("63000");
    auto output = ston<uint32_t>(input);
    decltype(output) expected = 63000;

    BOOST_TEST(output == expected);
}


BOOST_AUTO_TEST_CASE( ston_uint32_t_throw )
{
    string input("5000000000");

    BOOST_REQUIRE_THROW(ston<uint32_t>(input), ConversionError);
}


BOOST_AUTO_TEST_CASE( ston_uint32_t_bad )
{
    string input("very bad");

    BOOST_REQUIRE_THROW(ston<uint32_t>(input), ConversionError);
}


BOOST_AUTO_TEST_CASE( ston_uint64_t )
{
    string input("7000000000");
    auto output = ston<uint64_t>(input);
    decltype(output) expected = 7000000000;

    BOOST_TEST(output == expected);
}


BOOST_AUTO_TEST_CASE( ston_uint64_t_throw )
{
    string input("99999999999999999999999999999999999999999999999999999");

    BOOST_REQUIRE_THROW(ston<uint64_t>(input), ConversionError);
}


BOOST_AUTO_TEST_CASE( CIString_test )
{
   CIString first{ "ABCD" };
   CIString second{ "abcd" };

   BOOST_TEST(first == second);
}


BOOST_AUTO_TEST_CASE( SecondsSinceMidnight_print )
{
    string expected{ "01:12:30" };
    
    ostringstream oss;

    oss << SecondsSinceMidnight(4350);

    BOOST_TEST(oss.str() == expected);
}


BOOST_AUTO_TEST_CASE( oneDayInSeconds_test )
{
   auto calculated{ oneDayInSeconds() };
   decltype(calculated) expected{ 86400 };

   BOOST_TEST(calculated == expected);
}


BOOST_AUTO_TEST_CASE( diffInSeconds_test_1 )
{
   time_t calculated{ diffInSeconds(100, 600) };
   decltype(calculated) expected{ 500 };

   BOOST_TEST(calculated == expected);
}


BOOST_AUTO_TEST_CASE( diffInSeconds_test_2 )
{
   time_t calculated{ diffInSeconds(oneDayInSeconds() - 3, 6) };
   decltype(calculated) expected{ 9 };

   BOOST_TEST(calculated == expected);
}

BOOST_AUTO_TEST_CASE( diffInSeconds_test_3 )
{
   time_t calculated{ diffInSeconds(6, 6) };
   decltype(calculated) expected{ 0 };

   BOOST_TEST(calculated == expected);
}
