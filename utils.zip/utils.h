
//
//
//            ####  #  ####    ####
//           #      #      #  #
//          #       #       ##         (C) 2023 SIX Financial Information
//         #        #       ##             All rights reserved
//        #         #      #  #
//    ####          #  ####    ####
//
//
//
#pragma once
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <string_view>
#include <chrono>
#include <type_traits>
#include <filesystem>


using namespace std::chrono_literals;     //NOSONAR
namespace chr = std::chrono;
namespace fs = std::filesystem;


using namespace std;                      //NOSONAR


namespace cl {


   //n millisecond sleep
   void doSleep(const chr::milliseconds &n);


   //Returns number of milliseconds since Epoch
   inline uint64_t nowInMilliseconds(void)
   {
      return chr::duration_cast<chr::milliseconds>(chr::system_clock::now().time_since_epoch()).count();
   }


   //Returns current time as seconds since midnight
   inline time_t nowSSM(void)
   {
      auto today{ time(nullptr) };
      struct tm tm{};

      localtime_r(&today, &tm);

      return (tm.tm_hour * 3600) + (tm.tm_min * 60) + tm.tm_sec;
   }


   //Returns provided time_t time as seconds since midnight
   inline time_t timeSSM(time_t t)
   {
      struct tm tm{};

      localtime_r(&t, &tm);

      return (tm.tm_hour * 3600) + (tm.tm_min * 60) + tm.tm_sec;
   }


   //Returns number of seconds in 24 hours
   constexpr time_t oneDayInSeconds(void)
   {
      chr::duration<time_t> day{ 24h };

      return day.count();
   }


   //Calculates diff in seconds between from and to
   constexpr time_t diffInSeconds(time_t from, time_t to)
   {
      if (from > to)
      {
         return to + oneDayInSeconds() - from;
      }

      return to - from;
   }


   //Puts error message according to errno in the stream
   ostream &errNo(ostream &o);


   //Returns a lower case of a letter
   constexpr char toLower(char c)
   {
      if (isupper(c))
      {
         return c - 'A' + 'a';
      }

      return c;
   }


   //Trait class used to define case insensitive string
   class CITraits : public char_traits<char>
   {
      public:

         static constexpr bool eq(char_type a, char_type b) { return toLower(a) == toLower(b); }

         static constexpr bool lt(char_type a, char_type b) { return toLower(a) < toLower(b); }

         static constexpr int compare(const char_type* s1, const char_type* s2, size_t count)
         {
            for (; count; ++s1, ++s2, --count)
            {
               const char_type diff (toLower(*s1) - toLower(*s2));
               if (diff < 0)
               {
                  return -1;
               }
               else if (diff > 0)
               {
                  return +1;
               }
            }

            return 0;
         }

         static constexpr const char_type* find(const char_type* p, size_t count, const char_type& ch)
         {
            const char_type find_c{ toLower(ch) };

            for (; count != 0; --count, ++p)
            {
               if (find_c == toLower(*p))
               {
                  return p;
               }
            }

            return nullptr;
         }
   };


   //Case insensitive string and string_view
   using CIString = basic_string<char, CITraits>;
   using CIStringView = basic_string_view<char, CITraits>;


   //For easy printing
   ostream &operator<<(ostream &os, CIStringView str);


   //Exception used in toValue and ston functions
   class ConversionError : public invalid_argument
   {
      using invalid_argument::invalid_argument;
   };


   //Converts string to uint64_t value
   uint64_t toValue(const string &s);


   //Conversion string -> number
   template<typename T>
      T ston(const string &s)
      {
         auto val = toValue(s);

         if (val > numeric_limits<T>::max())
         {
            ostringstream o;

            o << val << " is too big to convert to " << sizeof(T) << " byte ";

            if (!is_signed_v<T>)
            {
               o << "un";
            }

            o << "signed integer";

            throw ConversionError(o.str());
         }
         
         return static_cast<T>(val);
      }


   //Generic class for printing with leading zeros and specified width
   template <typename T>
      struct LeadingZeros
      {
         LeadingZeros(T v, int w) : value(v), width(w) {}

         //What to print
         T value;
         //Field width
         int width;
      };


   //For printing
   template <typename T>
      ostream &operator<<(ostream &o, const LeadingZeros<T> &lz)
      {
         return o << setw(lz.width) << setfill('0') << lz.value;
      }


   //Exception used in processFile and openFile functions
   class ProcessFileError : public runtime_error
   {
      using runtime_error::runtime_error;
   };


   //Checks if file was opened
   //If not throws an exception
   template <typename T, typename Stream>
      void isOpened(const T &name, const Stream &stream)
      {
         if (!stream.good())
         {
            ostringstream s;

            s << "Unable to open file " << name << ' ' << errNo;
            throw ProcessFileError(s.str());
         }
      }


   //Opens the output file
   template <typename T, typename S>
      void openFile(const T &filename, S &stream, ios_base::openmode mode = ios::out)
      {
         if (stream.is_open())
         {
            return;
         }

         stream.open(filename, mode);
         isOpened(filename, stream);
      }


   //Function that reads text file and calls func on every line
   //Returns false when func returns false
   template <typename F>
      bool processFile(const string &n, F func)
      {
         ifstream f{ n };

         isOpened(n, f);

         string buffer;

         while (!getline(f, buffer).fail())
         {
            if (!func(buffer))
            {
               return false;
            }
         }

         return true;
      }


   //Time since epoch broken down into calendar parts
   class Tm
   {
      public:

         //C-tor with current time
         Tm(void) { convert(time(nullptr)); }

         //C-tor with provided time
         explicit Tm(time_t t) { convert(t); }

         //Returns ref to tm_
         inline const tm &get(void) const noexcept { return tm_; }

      private:

         //Converts time since epoch into calendar time
         void convert(time_t t)
         {
            localtime_r(&t, &tm_);
         }

         //Structure holding a calendar date and time broken down into its components
         tm tm_;
   };
   
    
   //For easy time_t formatting
   class TimePut
   {
      public:

         //C-tor
         TimePut(time_t t, const char *fmt) : time_{ t }, format_{ fmt } {}
         TimePut(time_t t, const string_view &fmt) : time_{ t }, format_{ fmt.data() } {}

         //Prints the time
         friend ostream &operator<<(ostream &o, const TimePut &tp)
         {
            Tm tm{ tp.time_ };
            
            return o << put_time(&tm.get(), tp.format_);
         }

      private:

         //The time to format
         const time_t time_;
         //Time formatting string
         const char *format_;
   };


   //For printing 'seconds since midnight' as HH:MM:SS
   class SecondsSinceMidnight
   {
      public:

         //C-tor
         explicit SecondsSinceMidnight(time_t t) : time_{ t } {}

         //Let's print!
         friend ostream &operator<<(ostream &o, const SecondsSinceMidnight &ssm)
         {
            auto tmp = ssm.time_;
            auto h = tmp / 3600;

            tmp %= 3600;

            auto m = tmp / 60;
            auto s = tmp % 60;

            return o << setw(2) << setfill('0') << h << ':' << setw(2) << setfill('0') << m << ':' << setw(2) << setfill('0') << s;
         }

      private:

         //Seconds since midnight
         time_t time_;   
   };


   //Constructs a string conatining '__PRETTY_FUNCTION__ failed'
   string failedStr(const char *f);


   //Conversion from TP time point to system clock time_t value
   template <typename TP>
      time_t toTimeT(TP tp)
      {
         auto sctp{ chr::time_point_cast<chr::system_clock::duration>(tp - TP::clock::now() + chr::system_clock::now()) };

         return chr::system_clock::to_time_t(sctp);
      }
      

   //Last modification time of the file as time_t
   //If file does not exist returns current time
   inline time_t last_write_time(const fs::path &file)
   {
      if (!fs::exists(file))
      {
         return time(nullptr);
      }

      return toTimeT<fs::file_time_type>(fs::last_write_time(file));
   }


   //Returns the file age in days
   time_t fileAgeInDays(const fs::path &file);


   //Returns day of year of file last modification time
   int fileDayOfYear(const fs::path &file);


   //Returns today's day of year
   int dayOfYear(void);


} // namespace cl
