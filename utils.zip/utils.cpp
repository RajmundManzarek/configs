
//
//
//            ####  #  ####    ####
//           #      #      #  #
//          #       #       ##         (C) 2023 SIX Financial Information
//         #        #       ##             All rights reserved
//        #         #      #  #
//    ####          #  ####    ####
//
//
//
#include "utils.h"


#include <algorithm>
#include <sstream>
#include <stdexcept>
#include <cerrno>
#include <cstring>
#include <thread>
#include <regex>


namespace cl {


   //n millisecond sleep
   void doSleep(const chr::milliseconds &n)
   {
      this_thread::sleep_for(n);
   }


   //Puts error message according to errno in the stream
   ostream &errNo(ostream &o)
   {
      array<char, 1024> buff{};

      return o << strerror_r(errno, buff.data(), buff.size()) << '.';
   }


   //Print in a stream
   ostream &operator<<(ostream &os, CIStringView str)
   {
      return os.write(str.data(), str.size());
   }


   //Converts string to uint64_t value
   uint64_t toValue(const string &s)
   {
      try
      {
         return stoull(s);
      }
      catch (const exception &)
      {
         ostringstream o;

         o << "Unable to convert '" << s << "' to a number";
         throw ConversionError(o.str());
      }
   }


   //Constructs a string conatining '__PRETTY_FUNCTION__ failed'
   string failedStr(const char *f)
   {
      static string failed{ " failed" };

      return string(f) + failed;
   }


   //Returns the file age in days
   time_t fileAgeInDays(const fs::path &file)
   {
      auto timeTFile{ cl::last_write_time(file) };
      auto timeTNow{ chr::system_clock::to_time_t(chr::system_clock::now()) };

      if (timeTNow <= timeTFile)
      {
         return 0;
      }

      return (timeTNow - timeTFile) / oneDayInSeconds();
   }

   //Returns day of year of file last modification time
   int fileDayOfYear(const fs::path &file)
   {
      auto timeTFile{ cl::last_write_time(file) };
      struct tm t;

      localtime_r(&timeTFile, &t);

      return t.tm_yday + 1;
   }


   //Returns today's day of year
   int dayOfYear(void)
   {
      auto current{ time(nullptr) };
      struct tm t;

      localtime_r(&current, &t);

      return t.tm_yday + 1;
   }


} // namespace cl
